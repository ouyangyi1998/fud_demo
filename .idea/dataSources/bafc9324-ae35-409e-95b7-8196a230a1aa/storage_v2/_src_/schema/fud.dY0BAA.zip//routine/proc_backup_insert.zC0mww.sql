create
    definer = `skip-grants user`@`skip-grants host` procedure proc_backup_insert()
BEGIN
    DECLARE pre_name VARCHAR(50);
    DECLARE pre_localUrl VARCHAR(50);
    DECLARE i INT;
    SET pre_name = 'test';
    SET pre_localUrl = '/home/sheva/test/backup/';
    SET i = 1;
    WHILE i <= 100000 DO
            INSERT INTO fud.backup(file_id, `name`, `local_url`, user_id) VALUES (i, CONCAT(pre_name, i), CONCAT(pre_localUrl, pre_name, i), i);
            SET i = i + 1;
        END WHILE;
END;

