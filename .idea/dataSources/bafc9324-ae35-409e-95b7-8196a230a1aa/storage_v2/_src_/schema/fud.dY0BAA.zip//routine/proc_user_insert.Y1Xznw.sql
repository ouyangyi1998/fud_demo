create
    definer = `skip-grants user`@`skip-grants host` procedure proc_user_insert()
BEGIN
    DECLARE pre_name VARCHAR(50);
    DECLARE u_password VARCHAR(50);
    DECLARE roleId BIGINT;
    DECLARE i INT;
    SET pre_name = 'user';
    SET u_password = '0b58be7994e42c16e91bbbb55c9b3994';
    SET roleId = 1;
    SET i = 1;
    WHILE i <= 100000 DO
            INSERT INTO fud.user(`username`, password, role_id) VALUES (CONCAT(pre_name, i), u_password, roleId);
            SET i = i + 1;
        END WHILE;
END;

